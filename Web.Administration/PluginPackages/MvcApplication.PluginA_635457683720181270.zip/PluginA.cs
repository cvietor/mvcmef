﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using MvcApplicationA.Plugin.Controllers;
using MvcApplication.Plugin.Framework;

namespace MvcApplication.PluginA
{
    public class PluginA : MyPlugin
    {
        public override void Load()
        {
            Bind<IMyPlugin>().To<PluginA>();
            Bind<IController>().To<PluginAController>()
                .Named(GetControllerName<PluginAController>());
        }
    }
}
