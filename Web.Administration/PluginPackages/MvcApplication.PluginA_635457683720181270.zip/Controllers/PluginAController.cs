﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using MvcApplication.Plugin.Framework;

namespace MvcApplicationA.Plugin.Controllers
{
    public class PluginAController : MyController
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
