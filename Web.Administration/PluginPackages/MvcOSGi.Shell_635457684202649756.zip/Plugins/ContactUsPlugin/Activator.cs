﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UIShell.OSGi;

namespace ContactUsPlugin
{
    public class Activator : IBundleActivator
    {
        public void Start(IBundleContext context)
        {
            
        }

        public void Stop(IBundleContext context)
        {
            
        }
    }
}